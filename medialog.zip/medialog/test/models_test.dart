import 'package:flutter_test/flutter_test.dart';
import 'package:medialog/models/media_entry.dart';
import 'package:medialog/models/media_types.dart';
import 'package:medialog/services/auth_service.dart';

void main() {
  test('MediaEntry survives a database round trip', () {
    final now = DateTime(2026, 11, 13, 9, 30);
    final entry = MediaEntry(
      id: 1,
      userId: 7,
      title: 'Dune',
      type: MediaType.book,
      status: EntryStatus.completed,
      rating: 5,
      notes: 'Spice.',
      dateConsumed: now,
      createdAt: now,
      updatedAt: now,
    );
    final copy = MediaEntry.fromMap(entry.toMap());
    expect(copy.title, 'Dune');
    expect(copy.type, MediaType.book);
    expect(copy.status, EntryStatus.completed);
    expect(copy.rating, 5);
    expect(copy.dateConsumed, now);
  });

  test('Unknown enum names fall back safely', () {
    expect(MediaType.fromName('podcast'), MediaType.movie);
    expect(EntryStatus.fromName('???'), EntryStatus.planned);
  });

  test('Password hashing verifies correct password only', () {
    final stored = AuthService.hashPassword('secret123');
    expect(stored.contains('secret123'), isFalse);
    expect(AuthService.verifyPassword('secret123', stored), isTrue);
    expect(AuthService.verifyPassword('wrong', stored), isFalse);
  });
}
