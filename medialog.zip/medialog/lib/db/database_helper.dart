import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

import '../models/app_user.dart';
import '../models/media_entry.dart';

/// All SQLite access lives here (singleton, one open connection).
class DatabaseHelper {
  DatabaseHelper._();
  static final DatabaseHelper instance = DatabaseHelper._();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _open();
    return _db!;
  }

  Future<Database> _open() async {
    final dir = await getDatabasesPath();
    return openDatabase(
      p.join(dir, 'medialog.db'),
      version: 2,
      onConfigure: (db) async {
        await db.execute('PRAGMA foreign_keys = ON');
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // v2 adds the offline cache for Open Library searches.
        if (oldVersion < 2) await _createApiCache(db);
      },
      onCreate: (db, version) async {
        await _createApiCache(db);
        await db.execute('''
          CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password_hash TEXT NOT NULL,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            title TEXT NOT NULL,
            media_type TEXT NOT NULL,
            status TEXT NOT NULL,
            rating REAL,
            notes TEXT,
            date_consumed TEXT,
            cover_path TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
          )
        ''');
      },
    );
  }

  static Future<void> _createApiCache(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS api_cache (
        query TEXT PRIMARY KEY,
        response_json TEXT NOT NULL,
        fetched_at TEXT NOT NULL
      )
    ''');
  }

  // ---------- API cache (Open Library results saved for offline use) ----------

  static String _cacheKey(String query) => query.trim().toLowerCase();

  Future<void> saveApiCache(String query, String responseJson) async {
    final db = await database;
    await db.insert(
      'api_cache',
      {
        'query': _cacheKey(query),
        'response_json': responseJson,
        'fetched_at': DateTime.now().toIso8601String(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  /// Returns (json, fetchedAt) or null if this search was never saved.
  Future<({String json, DateTime fetchedAt})?> getApiCache(String query) async {
    final db = await database;
    final rows = await db.query(
      'api_cache',
      where: 'query = ?',
      whereArgs: [_cacheKey(query)],
      limit: 1,
    );
    if (rows.isEmpty) return null;
    return (
      json: rows.first['response_json'] as String,
      fetchedAt: DateTime.parse(rows.first['fetched_at'] as String),
    );
  }

  // ---------- Users ----------

  Future<int> insertUser(AppUser user) async {
    final db = await database;
    return db.insert('users', user.toMap());
  }

  Future<AppUser?> getUserByEmail(String email) async {
    final db = await database;
    final rows = await db.query(
      'users',
      where: 'email = ?',
      whereArgs: [email],
      limit: 1,
    );
    return rows.isEmpty ? null : AppUser.fromMap(rows.first);
  }

  Future<AppUser?> getUserById(int id) async {
    final db = await database;
    final rows = await db.query('users', where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : AppUser.fromMap(rows.first);
  }

  // ---------- Entries (CRUD) ----------

  Future<int> insertEntry(MediaEntry entry) async {
    final db = await database;
    return db.insert('entries', entry.toMap());
  }

  Future<List<MediaEntry>> getEntries(int userId) async {
    final db = await database;
    final rows = await db.query(
      'entries',
      where: 'user_id = ?',
      whereArgs: [userId],
      orderBy: 'updated_at DESC',
    );
    return rows.map(MediaEntry.fromMap).toList();
  }

  Future<MediaEntry?> getEntry(int id) async {
    final db = await database;
    final rows = await db.query('entries', where: 'id = ?', whereArgs: [id], limit: 1);
    return rows.isEmpty ? null : MediaEntry.fromMap(rows.first);
  }

  Future<int> updateEntry(MediaEntry entry) async {
    final db = await database;
    return db.update(
      'entries',
      entry.toMap(),
      where: 'id = ?',
      whereArgs: [entry.id],
    );
  }

  Future<int> deleteEntry(int id) async {
    final db = await database;
    return db.delete('entries', where: 'id = ?', whereArgs: [id]);
  }
}
