import 'dart:convert';
import 'dart:math';

import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../db/database_helper.dart';
import '../models/app_user.dart';

class AuthException implements Exception {
  AuthException(this.message);
  final String message;
}

/// Local (on-device) sign up, login and session handling.
class AuthService {
  static const _sessionKey = 'current_user_id';

  /// Stores "salt:hash" so the same password never produces the same hash.
  static String hashPassword(String password, {String? salt}) {
    final s = salt ?? _newSalt();
    final digest = sha256.convert(utf8.encode('$s:$password'));
    return '$s:$digest';
  }

  static bool verifyPassword(String password, String stored) {
    final parts = stored.split(':');
    if (parts.length != 2) return false;
    return hashPassword(password, salt: parts[0]) == stored;
  }

  static String _newSalt() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    return base64UrlEncode(bytes);
  }

  static Future<AppUser> signUp({
    required String name,
    required String email,
    required String password,
  }) async {
    final db = DatabaseHelper.instance;
    final cleanEmail = email.trim().toLowerCase();
    if (await db.getUserByEmail(cleanEmail) != null) {
      throw AuthException('An account with that email already exists.');
    }
    final user = AppUser(
      name: name.trim(),
      email: cleanEmail,
      passwordHash: hashPassword(password),
      createdAt: DateTime.now(),
    );
    final id = await db.insertUser(user);
    await _saveSession(id);
    return (await db.getUserById(id))!;
  }

  static Future<AppUser> login({
    required String email,
    required String password,
  }) async {
    final user = await DatabaseHelper.instance.getUserByEmail(email.trim().toLowerCase());
    if (user == null || !verifyPassword(password, user.passwordHash)) {
      throw AuthException('Incorrect email or password.');
    }
    await _saveSession(user.id!);
    return user;
  }

  /// The logged-in user, or null if nobody is logged in.
  static Future<AppUser?> currentUser() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getInt(_sessionKey);
    if (id == null) return null;
    return DatabaseHelper.instance.getUserById(id);
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_sessionKey);
  }

  static Future<void> _saveSession(int userId) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_sessionKey, userId);
  }
}
