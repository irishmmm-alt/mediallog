import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

/// One book returned by the Open Library Search API.
class BookResult {
  const BookResult({
    required this.title,
    required this.authors,
    this.firstPublishYear,
    this.coverId,
  });

  final String title;
  final List<String> authors;
  final int? firstPublishYear;
  final int? coverId;

  /// Small cover for the results list, medium/large for saving.
  String? coverUrl({String size = 'M'}) => coverId == null
      ? null
      : 'https://covers.openlibrary.org/b/id/$coverId-$size.jpg';

  String get authorText => authors.isEmpty ? 'Unknown author' : authors.join(', ');

  factory BookResult.fromJson(Map<String, dynamic> json) => BookResult(
        title: (json['title'] as String?) ?? 'Untitled',
        authors: ((json['author_name'] as List?) ?? const [])
            .map((a) => a.toString())
            .toList(),
        firstPublishYear: json['first_publish_year'] as int?,
        coverId: json['cover_i'] as int?,
      );
}

/// What the screen receives after a successful request.
class BookSearchResponse {
  const BookSearchResponse({
    required this.statusCode,
    required this.totalFound,
    required this.books,
  });

  final int statusCode;
  final int totalFound;
  final List<BookResult> books;
}

class ApiException implements Exception {
  ApiException(this.message, {this.statusCode});
  final String message;
  final int? statusCode;

  @override
  String toString() => message;
}

/// Talks to the Open Library Search API (https://openlibrary.org/dev/docs/api/search).
/// Free, no API key needed.
class BookApiService {
  static const _host = 'openlibrary.org';
  static const _searchPath = '/search.json';
  static const _timeout = Duration(seconds: 15);
  static const _headers = {
    // Open Library asks apps to identify themselves.
    'User-Agent': 'MediaLog/1.0 (student Flutter project)',
    'Accept': 'application/json',
  };

  /// GET https://openlibrary.org/search.json?q=<query>&limit=15&fields=...
  static Uri searchUri(String query) => Uri.https(_host, _searchPath, {
        'q': query,
        'limit': '15',
        'fields': 'title,author_name,first_publish_year,cover_i',
      });

  static Future<BookSearchResponse> searchBooks(String query) async {
    final http.Response response;
    try {
      response = await http.get(searchUri(query), headers: _headers).timeout(_timeout);
    } on SocketException catch (e) {
      throw ApiException('No internet connection. Check your data or Wi-Fi.\n(${e.message})');
    } on TimeoutException {
      throw ApiException('The server took too long to respond. Try again.');
    } on http.ClientException catch (e) {
      throw ApiException('Could not reach Open Library. Check your connection.\n(${e.message})');
    }

    // 1) Check the HTTP status before touching the body.
    if (response.statusCode != 200) {
      throw ApiException(
        'Open Library responded with HTTP ${response.statusCode}.',
        statusCode: response.statusCode,
      );
    }

    // 2) Parse the JSON body.
    try {
      final data = jsonDecode(response.body) as Map<String, dynamic>;
      final docs = (data['docs'] as List? ?? const [])
          .whereType<Map<String, dynamic>>()
          .map(BookResult.fromJson)
          .toList();
      return BookSearchResponse(
        statusCode: response.statusCode,
        totalFound: (data['numFound'] as int?) ?? docs.length,
        books: docs,
      );
    } on FormatException {
      throw ApiException('Received data in an unexpected format.');
    } on TypeError {
      throw ApiException('Received data in an unexpected format.');
    }
  }

  /// Downloads a cover image (GET) and returns its bytes.
  static Future<List<int>> downloadCover(String url) async {
    final response = await http.get(Uri.parse(url), headers: _headers).timeout(_timeout);
    if (response.statusCode != 200) {
      throw ApiException('Cover download failed (HTTP ${response.statusCode}).',
          statusCode: response.statusCode);
    }
    return response.bodyBytes;
  }
}
