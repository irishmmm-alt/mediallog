const _months = [
  'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
];

String monthShort(int month) => _months[month - 1];

/// e.g. "Nov 12, 2026"
String formatDate(DateTime d) => '${monthShort(d.month)} ${d.day}, ${d.year}';

const ratingWords = ['No rating', 'Bad', 'Meh', 'Good', 'Great', 'Masterpiece'];
