/// A registered account stored on the device.
class AppUser {
  const AppUser({
    this.id,
    required this.name,
    required this.email,
    required this.passwordHash,
    required this.createdAt,
  });

  final int? id;
  final String name;
  final String email;
  final String passwordHash; // never the plain password
  final DateTime createdAt;

  String get firstName => name.trim().split(' ').first;

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'name': name,
        'email': email,
        'password_hash': passwordHash,
        'created_at': createdAt.toIso8601String(),
      };

  factory AppUser.fromMap(Map<String, Object?> map) => AppUser(
        id: map['id'] as int?,
        name: map['name'] as String,
        email: map['email'] as String,
        passwordHash: map['password_hash'] as String,
        createdAt: DateTime.parse(map['created_at'] as String),
      );
}
