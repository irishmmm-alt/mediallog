import 'package:flutter/material.dart';

/// The kinds of media a user can log.
enum MediaType {
  movie('Movie', Icons.movie_outlined, Color(0xFFE4572E)),
  series('Series', Icons.live_tv_outlined, Color(0xFF7B5EA7)),
  book('Book', Icons.menu_book_outlined, Color(0xFF2A9D8F)),
  article('Article', Icons.article_outlined, Color(0xFFD9922E));

  const MediaType(this.label, this.icon, this.color);

  final String label;
  final IconData icon;
  final Color color;

  /// Converts the text stored in the database back into a MediaType.
  static MediaType fromName(String name) => MediaType.values.firstWhere(
        (t) => t.name == name,
        orElse: () => MediaType.movie,
      );
}

/// Where the user is with an entry.
enum EntryStatus {
  planned('Plan to Consume', Icons.bookmark_border, Color(0xFF5C7AEA)),
  inProgress('In Progress', Icons.timelapse, Color(0xFFD9922E)),
  completed('Completed', Icons.check_circle_outline, Color(0xFF2E9D5B));

  const EntryStatus(this.label, this.icon, this.color);

  final String label;
  final IconData icon;
  final Color color;

  static EntryStatus fromName(String name) => EntryStatus.values.firstWhere(
        (s) => s.name == name,
        orElse: () => EntryStatus.planned,
      );
}
