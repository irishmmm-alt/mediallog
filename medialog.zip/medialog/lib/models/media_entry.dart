import 'media_types.dart';

/// One logged item: a movie, series, book or article.
class MediaEntry {
  const MediaEntry({
    this.id,
    required this.userId,
    required this.title,
    required this.type,
    required this.status,
    this.rating,
    this.notes,
    this.dateConsumed,
    this.coverPath,
    required this.createdAt,
    required this.updatedAt,
  });

  final int? id;
  final int userId;
  final String title;
  final MediaType type;
  final EntryStatus status;
  final double? rating; // 1 to 5, null = not rated
  final String? notes;
  final DateTime? dateConsumed;
  final String? coverPath; // local file path of the cover image
  final DateTime createdAt;
  final DateTime updatedAt;

  /// Date used for sorting: when it was consumed, or when it was added.
  DateTime get sortDate => dateConsumed ?? createdAt;

  Map<String, Object?> toMap() => {
        if (id != null) 'id': id,
        'user_id': userId,
        'title': title,
        'media_type': type.name,
        'status': status.name,
        'rating': rating,
        'notes': notes,
        'date_consumed': dateConsumed?.toIso8601String(),
        'cover_path': coverPath,
        'created_at': createdAt.toIso8601String(),
        'updated_at': updatedAt.toIso8601String(),
      };

  factory MediaEntry.fromMap(Map<String, Object?> map) => MediaEntry(
        id: map['id'] as int?,
        userId: map['user_id'] as int,
        title: map['title'] as String,
        type: MediaType.fromName(map['media_type'] as String),
        status: EntryStatus.fromName(map['status'] as String),
        rating: (map['rating'] as num?)?.toDouble(),
        notes: map['notes'] as String?,
        dateConsumed: map['date_consumed'] == null
            ? null
            : DateTime.parse(map['date_consumed'] as String),
        coverPath: map['cover_path'] as String?,
        createdAt: DateTime.parse(map['created_at'] as String),
        updatedAt: DateTime.parse(map['updated_at'] as String),
      );

  MediaEntry copyWith({
    EntryStatus? status,
    DateTime? dateConsumed,
    DateTime? updatedAt,
  }) =>
      MediaEntry(
        id: id,
        userId: userId,
        title: title,
        type: type,
        status: status ?? this.status,
        rating: rating,
        notes: notes,
        dateConsumed: dateConsumed ?? this.dateConsumed,
        coverPath: coverPath,
        createdAt: createdAt,
        updatedAt: updatedAt ?? this.updatedAt,
      );
}
