import 'package:flutter/material.dart';

import '../models/media_entry.dart';
import '../models/media_types.dart';
import '../utils/format.dart';
import 'animations.dart';
import 'cover_image.dart';
import 'rating_stars.dart';

/// Side padding that keeps content readable on tablets (max ~720px wide).
double sidePadding(BuildContext context) {
  final w = MediaQuery.sizeOf(context).width;
  return w > 752 ? (w - 720) / 2 : 16;
}

/// Small colored pill showing an entry's status.
class StatusBadge extends StatelessWidget {
  const StatusBadge({super.key, required this.status});

  final EntryStatus status;

  @override
  Widget build(BuildContext context) {
    // Lighten the text in dark mode so it keeps enough contrast.
    final dark = Theme.of(context).brightness == Brightness.dark;
    final fg = dark ? Color.lerp(status.color, Colors.white, 0.45)! : status.color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: status.color.withValues(alpha: 0.14),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(status.icon, size: 13, color: fg),
          const SizedBox(width: 4),
          Text(
            status.label,
            style: TextStyle(
              fontSize: 11.5,
              fontWeight: FontWeight.w600,
              color: fg,
            ),
          ),
        ],
      ),
    );
  }
}

/// Bold heading used between sections.
class SectionTitle extends StatelessWidget {
  const SectionTitle(this.text, {super.key, this.trailing});

  final String text;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 10),
      child: Row(
        children: [
          Expanded(
            child: Text(
              text,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
          ),
          if (trailing != null) trailing!,
        ],
      ),
    );
  }
}

/// One number on the dashboard. The number counts up when it appears.
class StatCard extends StatelessWidget {
  const StatCard({
    super.key,
    required this.label,
    required this.number,
    required this.icon,
    required this.color,
    this.decimals = 0,
    this.suffix = '',
  });

  final String label;
  final double? number; // null = nothing to show yet ("-")
  final IconData icon;
  final Color color;
  final int decimals;
  final String suffix;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    final valueStyle = text.headlineSmall?.copyWith(fontWeight: FontWeight.w800);
    final n = number;
    final spoken = n == null ? 'none yet' : '${n.toStringAsFixed(decimals)}$suffix';
    return Semantics(
      label: '$label: $spoken',
      excludeSemantics: true,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.10),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color),
            const SizedBox(height: 10),
            // FittedBox keeps big numbers / large system fonts from overflowing.
            FittedBox(
              fit: BoxFit.scaleDown,
              alignment: Alignment.centerLeft,
              child: n == null
                  ? Text('-', style: valueStyle)
                  : AnimatedCount(
                      value: n,
                      decimals: decimals,
                      suffix: suffix,
                      style: valueStyle,
                    ),
            ),
            Text(label, style: text.bodySmall, maxLines: 2, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

/// Row used in lists: cover, title, type, date, status and stars.
class EntryTile extends StatelessWidget {
  const EntryTile({super.key, required this.entry, required this.onTap});

  final MediaEntry entry;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    final date = entry.dateConsumed;
    return Card(
      elevation: 0,
      color: scheme.surfaceContainerLow,
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              // Hero: the cover "flies" into the Entry Detail screen.
              Hero(
                tag: 'cover-${entry.id}',
                child: CoverImage(
                  path: entry.coverPath,
                  type: entry.type,
                  width: 52,
                  height: 72,
                  radius: 8,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      entry.title,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Icon(entry.type.icon, size: 14, color: entry.type.color),
                        const SizedBox(width: 4),
                        Flexible(
                          child: Text(
                            date == null
                                ? entry.type.label
                                : '${entry.type.label} · ${formatDate(date)}',
                            overflow: TextOverflow.ellipsis,
                            style: text.bodySmall,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        StatusBadge(status: entry.status),
                        const Spacer(),
                        if (entry.rating != null)
                          RatingStars(rating: entry.rating!, size: 15),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Friendly message when there is nothing to show.
class EmptyState extends StatelessWidget {
  const EmptyState({
    super.key,
    required this.icon,
    required this.title,
    required this.message,
  });

  final IconData icon;
  final String title;
  final String message;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 40, horizontal: 24),
      child: Column(
        children: [
          Icon(icon, size: 56, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 12),
          Text(title, style: text.titleMedium, textAlign: TextAlign.center),
          const SizedBox(height: 6),
          Text(message, style: text.bodyMedium, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
