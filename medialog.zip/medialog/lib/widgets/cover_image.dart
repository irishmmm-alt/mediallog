import 'dart:io';
import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/media_types.dart';

/// Shows the entry's cover, or a colored placeholder with the media icon.
class CoverImage extends StatelessWidget {
  const CoverImage({
    super.key,
    required this.path,
    required this.type,
    required this.width,
    required this.height,
    this.radius = 10,
  });

  final String? path;
  final MediaType type;
  final double width;
  final double height;
  final double radius;

  @override
  Widget build(BuildContext context) {
    final coverPath = path;
    final file = coverPath == null ? null : File(coverPath);
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: SizedBox(
        width: width,
        height: height,
        child: (file != null && file.existsSync())
            ? Image.file(
                file,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stack) => _placeholder(),
              )
            : _placeholder(),
      ),
    );
  }

  Widget _placeholder() {
    return Container(
      color: type.color.withValues(alpha: 0.16),
      alignment: Alignment.center,
      child: Icon(
        type.icon,
        color: type.color,
        size: math.min(width, height) * 0.42,
      ),
    );
  }
}
