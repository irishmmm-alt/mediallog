import 'package:flutter/material.dart';

/// Shows 0–5 stars. Pass [onChanged] to make the stars tappable.
/// Tapping the currently selected star clears the rating.
class RatingStars extends StatelessWidget {
  const RatingStars({
    super.key,
    required this.rating,
    this.size = 18,
    this.onChanged,
  });

  final double rating;
  final double size;
  final ValueChanged<double>? onChanged;

  static const starColor = Color(0xFFF2B01E);

  @override
  Widget build(BuildContext context) {
    final empty = Theme.of(context).colorScheme.outlineVariant;
    final row = Row(
      mainAxisSize: MainAxisSize.min,
      children: List.generate(5, (i) {
        final position = i + 1;
        final IconData icon;
        if (rating >= position) {
          icon = Icons.star_rounded;
        } else if (rating >= position - 0.5) {
          icon = Icons.star_half_rounded;
        } else {
          icon = Icons.star_outline_rounded;
        }
        final star = Icon(
          icon,
          size: size,
          color: rating >= position - 0.5 ? starColor : empty,
        );
        final callback = onChanged;
        if (callback == null) return star;
        return IconButton(
          onPressed: () => callback(rating == position ? 0 : position.toDouble()),
          icon: star,
          tooltip: '$position star${position > 1 ? 's' : ''}',
          visualDensity: VisualDensity.compact,
        );
      }),
    );
    // Screen readers hear "Rating: 4 out of 5" instead of five separate icons.
    if (onChanged != null) return row;
    return Semantics(
      label: 'Rating: ${rating.toStringAsFixed(0)} out of 5',
      excludeSemantics: true,
      child: row,
    );
  }
}
