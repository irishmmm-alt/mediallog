import 'package:flutter/material.dart';

import '../services/book_api_service.dart';
import '../utils/format.dart';
import '../widgets/common.dart';

/// Searches Open Library and returns the chosen [BookResult] to the caller.
class BookSearchScreen extends StatefulWidget {
  const BookSearchScreen({super.key, this.initialQuery = ''});

  final String initialQuery;

  @override
  State<BookSearchScreen> createState() => _BookSearchScreenState();
}

enum _State { idle, loading, success, error }

class _BookSearchScreenState extends State<BookSearchScreen> {
  late final TextEditingController _query =
      TextEditingController(text: widget.initialQuery);
  _State _state = _State.idle;
  BookSearchResponse? _response;
  String? _error;

  @override
  void initState() {
    super.initState();
    if (widget.initialQuery.trim().isNotEmpty) {
      // Wait for the first frame so context lookups inside _search are safe.
      WidgetsBinding.instance.addPostFrameCallback((_) => _search());
    }
  }

  @override
  void dispose() {
    _query.dispose();
    super.dispose();
  }

  Future<void> _search() async {
    final q = _query.text.trim();
    if (q.isEmpty) return;
    FocusScope.of(context).unfocus();
    setState(() {
      _state = _State.loading;
      _error = null;
    });
    try {
      final result = await BookApiService.searchBooks(q);
      if (!mounted) return;
      setState(() {
        _response = result;
        _state = _State.success;
      });
    } on ApiException catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.message;
        _state = _State.error;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = 'Something went wrong: $e';
        _state = _State.error;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Search books online')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _query,
                    textInputAction: TextInputAction.search,
                    onSubmitted: (_) => _search(),
                    decoration: const InputDecoration(
                      hintText: 'Book title or author',
                      prefixIcon: Icon(Icons.search),
                      isDense: true,
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                FilledButton(
                  onPressed: _state == _State.loading ? null : _search,
                  child: const Text('Search'),
                ),
              ],
            ),
          ),
          Expanded(child: _buildBody()),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Text(
              'Data from Open Library API (openlibrary.org)',
              style: Theme.of(context).textTheme.labelSmall,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    final scheme = Theme.of(context).colorScheme;
    switch (_state) {
      case _State.idle:
        return const EmptyState(
          icon: Icons.travel_explore,
          title: 'Find a book',
          message: 'Search Open Library to auto-fill the title and cover.',
        );

      case _State.loading:
        return const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              CircularProgressIndicator(),
              SizedBox(height: 12),
              Text('Contacting Open Library...'),
            ],
          ),
        );

      case _State.error:
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.cloud_off, size: 56, color: scheme.error),
                const SizedBox(height: 12),
                Text('Request failed',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 6),
                Text(_error ?? 'Unknown error', textAlign: TextAlign.center),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: _search,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Try again'),
                ),
              ],
            ),
          ),
        );

      case _State.success:
        final res = _response!;
        return Column(
          children: [
            // Visible proof of where the data came from (for testing / screenshots).
            Container(
              width: double.infinity,
              margin: const EdgeInsets.symmetric(horizontal: 16),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(
                color: (res.fromCache ? const Color(0xFFD9922E) : const Color(0xFF2E9D5B))
                    .withValues(alpha: 0.14),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                res.fromCache
                    ? 'OFFLINE · showing saved results from SQLite (${formatDate(res.cachedAt!)}) · ${res.books.length} books'
                    : 'HTTP ${res.statusCode} OK · ${res.totalFound} matches · showing ${res.books.length} · saved for offline',
                style: TextStyle(
                  color: res.fromCache ? const Color(0xFFD9922E) : const Color(0xFF2E9D5B),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
            Expanded(
              child: res.books.isEmpty
                  ? const EmptyState(
                      icon: Icons.search_off,
                      title: 'No books found',
                      message: 'Try a different title or spelling.',
                    )
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                      itemCount: res.books.length,
                      itemBuilder: (context, i) => _BookTile(
                        book: res.books[i],
                        onTap: () => Navigator.of(context).pop(res.books[i]),
                      ),
                    ),
            ),
          ],
        );
    }
  }
}

class _BookTile extends StatelessWidget {
  const _BookTile({required this.book, required this.onTap});

  final BookResult book;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    final url = book.coverUrl(size: 'S');
    final placeholder = Container(
      width: 48,
      height: 68,
      color: scheme.surfaceContainerHighest,
      child: const Icon(Icons.menu_book_outlined),
    );
    return Card(
      elevation: 0,
      color: scheme.surfaceContainerLow,
      margin: const EdgeInsets.only(bottom: 10),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: url == null
                    ? placeholder
                    : Image.network(
                        url,
                        width: 48,
                        height: 68,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stack) => placeholder,
                      ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(book.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: text.titleSmall?.copyWith(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(
                      book.firstPublishYear == null
                          ? book.authorText
                          : '${book.authorText} · ${book.firstPublishYear}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: text.bodySmall,
                    ),
                  ],
                ),
              ),
              const Icon(Icons.add_circle_outline),
            ],
          ),
        ),
      ),
    );
  }
}
