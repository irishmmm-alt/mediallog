import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/app_user.dart';
import '../models/media_entry.dart';
import '../models/media_types.dart';
import '../services/auth_service.dart';
import '../utils/format.dart';
import '../widgets/animations.dart';
import '../widgets/common.dart';
import 'entry_detail_screen.dart';
import 'entry_form_screen.dart';
import 'login_screen.dart';
import 'media_list_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key, required this.user});

  final AppUser user;

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  List<MediaEntry> _entries = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final entries = await DatabaseHelper.instance.getEntries(widget.user.id!);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _loading = false;
      });
    } catch (e) {
      // Storage error: keep the app running and tell the user.
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not load your saved log. Pull down to retry.')),
      );
    }
  }

  // ---------- Stats ----------

  int _countStatus(EntryStatus s) => _entries.where((e) => e.status == s).length;
  int _countType(MediaType t) => _entries.where((e) => e.type == t).length;

  double? get _averageRating {
    final rated = _entries.where((e) => e.rating != null && e.rating! > 0).toList();
    if (rated.isEmpty) return null;
    final sum = rated.fold<double>(0, (total, e) => total + e.rating!);
    return sum / rated.length;
  }

  bool _isCompletedIn(MediaEntry e, DateTime month) {
    final d = e.dateConsumed;
    return e.status == EntryStatus.completed &&
        d != null &&
        d.year == month.year &&
        d.month == month.month;
  }

  int get _completedThisMonth {
    final now = DateTime.now();
    return _entries.where((e) => _isCompletedIn(e, now)).length;
  }

  /// Completed entries per month for the last 6 months (oldest first).
  List<MapEntry<DateTime, int>> get _lastSixMonths {
    final now = DateTime.now();
    return List.generate(6, (i) {
      final month = DateTime(now.year, now.month - 5 + i);
      final count = _entries.where((e) => _isCompletedIn(e, month)).length;
      return MapEntry(month, count);
    });
  }

  // ---------- Navigation ----------

  Future<void> _openList({MediaType? type, EntryStatus? status}) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => MediaListScreen(
        user: widget.user,
        initialType: type,
        initialStatus: status,
      ),
    ));
    _load();
  }

  Future<void> _addEntry() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (_) => EntryFormScreen(user: widget.user),
    ));
    await _load();
    if (saved == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Entry added to your log')),
      );
    }
  }

  Future<void> _openEntry(MediaEntry entry) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => EntryDetailScreen(user: widget.user, entry: entry),
    ));
    _load();
  }

  Future<void> _logout() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Log out?'),
        content: const Text('Your log stays saved on this device.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Log out'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    await AuthService.logout();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LoginScreen()),
      (route) => false,
    );
  }

  // ---------- UI ----------

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('Hi, ${widget.user.firstName}'),
        actions: [
          IconButton(
            onPressed: () => _openList(),
            icon: const Icon(Icons.library_books_outlined),
            tooltip: 'My log',
          ),
          IconButton(
            onPressed: _logout,
            icon: const Icon(Icons.logout),
            tooltip: 'Log out',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addEntry,
        icon: const Icon(Icons.add),
        label: const Text('Add entry'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: EdgeInsets.fromLTRB(sidePadding(context), 8, sidePadding(context), 100),
                children: [
                  _buildStatGrid(scheme),
                  if (_entries.isEmpty)
                    const EmptyState(
                      icon: Icons.auto_stories_outlined,
                      title: 'Your log is empty',
                      message:
                          'Tap "Add entry" to log the last movie, series, book or article you finished.',
                    )
                  else ...[
                    const SectionTitle('By status'),
                    _buildStatusRow(),
                    const SectionTitle('By media type'),
                    _buildTypeBreakdown(scheme),
                    const SectionTitle('Completed, last 6 months'),
                    _MonthlyChart(data: _lastSixMonths),
                    SectionTitle(
                      'Recently updated',
                      trailing: TextButton(
                        onPressed: () => _openList(),
                        child: const Text('See all'),
                      ),
                    ),
                    for (final (i, e) in _entries.take(5).indexed)
                      FadeSlideIn(
                        index: i,
                        child: EntryTile(entry: e, onTap: () => _openEntry(e)),
                      ),
                  ],
                ],
              ),
            ),
    );
  }

  Widget _buildStatGrid(ColorScheme scheme) {
    final cards = [
      StatCard(
        label: 'Total logged',
        number: _entries.length.toDouble(),
        icon: Icons.library_books_outlined,
        color: scheme.primary,
      ),
      StatCard(
        label: 'Completed',
        number: _countStatus(EntryStatus.completed).toDouble(),
        icon: Icons.task_alt,
        color: EntryStatus.completed.color,
      ),
      StatCard(
        label: 'Average rating',
        number: _averageRating,
        decimals: 1,
        suffix: ' / 5',
        icon: Icons.star_outline_rounded,
        color: const Color(0xFFB26A00),
      ),
      StatCard(
        label: 'Finished this month',
        number: _completedThisMonth.toDouble(),
        icon: Icons.calendar_month_outlined,
        color: const Color(0xFF7B5EA7),
      ),
    ];
    // Responsive: 4 cards in one row on wide screens/tablets, 2x2 on phones.
    return LayoutBuilder(builder: (context, constraints) {
      final perRow = constraints.maxWidth >= 600 ? 4 : 2;
      final rows = <Widget>[];
      for (var i = 0; i < cards.length; i += perRow) {
        if (rows.isNotEmpty) rows.add(const SizedBox(height: 12));
        rows.add(Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var j = i; j < i + perRow; j++) ...[
              if (j > i) const SizedBox(width: 12),
              Expanded(child: cards[j]),
            ],
          ],
        ));
      }
      return Column(children: rows);
    });
  }

  Widget _buildStatusRow() {
    return Row(
      children: [
        for (final s in EntryStatus.values) ...[
          Expanded(
            child: Material(
              color: s.color.withValues(alpha: 0.10),
              borderRadius: BorderRadius.circular(14),
              child: InkWell(
                borderRadius: BorderRadius.circular(14),
                onTap: () => _openList(status: s),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
                  child: Column(
                    children: [
                      Icon(s.icon, color: s.color),
                      const SizedBox(height: 6),
                      Text(
                        '${_countStatus(s)}',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                      ),
                      Text(
                        s.label,
                        textAlign: TextAlign.center,
                        style: const TextStyle(fontSize: 11.5),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          if (s != EntryStatus.values.last) const SizedBox(width: 8),
        ],
      ],
    );
  }

  Widget _buildTypeBreakdown(ColorScheme scheme) {
    final total = _entries.length;
    return Column(
      children: [
        for (final t in MediaType.values)
          InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => _openList(type: t),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 6),
              child: Row(
                children: [
                  Icon(t.icon, color: t.color, size: 20),
                  const SizedBox(width: 10),
                  SizedBox(width: 64, child: Text(t.label)),
                  Expanded(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      // Bars grow from 0 to their value.
                      child: TweenAnimationBuilder<double>(
                        tween: Tween(begin: 0, end: total == 0 ? 0 : _countType(t) / total),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutCubic,
                        builder: (context, v, _) => LinearProgressIndicator(
                          value: v,
                          minHeight: 10,
                          color: t.color,
                          backgroundColor: scheme.surfaceContainerHighest,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  SizedBox(
                    width: 28,
                    child: Text(
                      '${_countType(t)}',
                      textAlign: TextAlign.end,
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }
}

/// Simple bar chart drawn with plain containers (no chart package needed).
class _MonthlyChart extends StatelessWidget {
  const _MonthlyChart({required this.data});

  final List<MapEntry<DateTime, int>> data;

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final small = Theme.of(context).textTheme.labelSmall;
    final maxCount = data.fold<int>(0, (m, e) => e.value > m ? e.value : m);
    return SizedBox(
      height: 140,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          for (final e in data)
            Expanded(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 6),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Text('${e.value}', style: small),
                    const SizedBox(height: 4),
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 400),
                      height: maxCount == 0 ? 4 : 4 + 86 * e.value / maxCount,
                      decoration: BoxDecoration(
                        color: e.value == 0
                            ? scheme.surfaceContainerHighest
                            : scheme.primary,
                        borderRadius: BorderRadius.circular(6),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(monthShort(e.key.month), style: small),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
