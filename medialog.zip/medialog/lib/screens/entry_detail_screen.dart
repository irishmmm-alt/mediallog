import 'dart:io';

import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/app_user.dart';
import '../models/media_entry.dart';
import '../models/media_types.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import '../widgets/cover_image.dart';
import '../widgets/rating_stars.dart';
import 'entry_form_screen.dart';

class EntryDetailScreen extends StatefulWidget {
  const EntryDetailScreen({super.key, required this.user, required this.entry});

  final AppUser user;
  final MediaEntry entry;

  @override
  State<EntryDetailScreen> createState() => _EntryDetailScreenState();
}

class _EntryDetailScreenState extends State<EntryDetailScreen> {
  late MediaEntry _entry = widget.entry;

  Future<void> _reload() async {
    final fresh = await DatabaseHelper.instance.getEntry(_entry.id!);
    if (!mounted) return;
    if (fresh == null) {
      Navigator.of(context).pop();
      return;
    }
    setState(() => _entry = fresh);
  }

  Future<void> _edit() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (_) => EntryFormScreen(user: widget.user, entry: _entry),
    ));
    if (saved == true) _reload();
  }

  /// Quick status change without opening the full edit form.
  Future<void> _setStatus(EntryStatus status) async {
    if (status == _entry.status) return;
    final updated = _entry.copyWith(
      status: status,
      dateConsumed: status == EntryStatus.completed && _entry.dateConsumed == null
          ? DateTime.now()
          : null,
      updatedAt: DateTime.now(),
    );
    await DatabaseHelper.instance.updateEntry(updated);
    if (!mounted) return;
    setState(() => _entry = updated);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Moved to ${status.label}')),
    );
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete entry?'),
        content: Text('"${_entry.title}" will be removed from your log.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
            ),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;

    await DatabaseHelper.instance.deleteEntry(_entry.id!);
    final cover = _entry.coverPath;
    if (cover != null) {
      try {
        await File(cover).delete();
      } catch (_) {
        // Image already gone; nothing to do.
      }
    }
    if (!mounted) return;
    Navigator.of(context).pop(true);
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    final e = _entry;
    final notes = e.notes;
    final date = e.dateConsumed;

    return Scaffold(
      appBar: AppBar(
        actions: [
          IconButton(
            onPressed: _edit,
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'Edit',
          ),
          IconButton(
            onPressed: _delete,
            icon: const Icon(Icons.delete_outline),
            tooltip: 'Delete',
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 32),
        children: [
          Center(
            child: CoverImage(
              path: e.coverPath,
              type: e.type,
              width: 170,
              height: 240,
              radius: 16,
            ),
          ),
          const SizedBox(height: 20),
          Text(
            e.title,
            textAlign: TextAlign.center,
            style: text.headlineSmall?.copyWith(fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(e.type.icon, size: 18, color: e.type.color),
              const SizedBox(width: 4),
              Text(e.type.label, style: text.bodyMedium),
              const SizedBox(width: 12),
              StatusBadge(status: e.status),
            ],
          ),
          const SizedBox(height: 16),
          if (e.rating != null)
            Column(
              children: [
                RatingStars(rating: e.rating!, size: 30),
                const SizedBox(height: 4),
                Text(
                  '${e.rating!.toStringAsFixed(0)} / 5 · ${ratingWords[e.rating!.round()]}',
                  style: text.bodySmall,
                ),
              ],
            )
          else
            Text(
              e.status == EntryStatus.planned ? 'Not consumed yet' : 'Not rated yet',
              textAlign: TextAlign.center,
              style: text.bodySmall,
            ),

          const SectionTitle('Details'),
          _InfoRow(
            icon: Icons.calendar_today_outlined,
            label: 'Date consumed',
            value: date == null ? 'Not set' : formatDate(date),
          ),
          _InfoRow(
            icon: Icons.add_circle_outline,
            label: 'Added',
            value: formatDate(e.createdAt),
          ),
          _InfoRow(
            icon: Icons.update,
            label: 'Last updated',
            value: formatDate(e.updatedAt),
          ),

          const SectionTitle('Review / notes'),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: scheme.surfaceContainerLow,
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              notes ?? 'No notes yet. Tap edit to add your thoughts.',
              style: notes == null
                  ? text.bodyMedium?.copyWith(color: scheme.onSurfaceVariant)
                  : text.bodyLarge,
            ),
          ),

          const SectionTitle('Update status'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              for (final s in EntryStatus.values)
                ChoiceChip(
                  label: Text(s.label),
                  avatar: Icon(s.icon, size: 18),
                  showCheckmark: false,
                  selected: e.status == s,
                  onSelected: (_) => _setStatus(s),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.icon, required this.label, required this.value});

  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    final text = Theme.of(context).textTheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20, color: Theme.of(context).colorScheme.outline),
          const SizedBox(width: 12),
          Expanded(child: Text(label, style: text.bodyMedium)),
          Text(value, style: text.bodyMedium?.copyWith(fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
