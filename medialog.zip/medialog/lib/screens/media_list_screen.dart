import 'package:flutter/material.dart';

import '../db/database_helper.dart';
import '../models/app_user.dart';
import '../models/media_entry.dart';
import '../models/media_types.dart';
import '../widgets/animations.dart';
import '../widgets/common.dart';
import 'entry_detail_screen.dart';
import 'entry_form_screen.dart';

enum SortOption {
  newest('Newest first'),
  oldest('Oldest first'),
  ratingHigh('Highest rated'),
  ratingLow('Lowest rated'),
  titleAZ('Title A to Z'),
  updated('Recently updated');

  const SortOption(this.label);
  final String label;
}

class MediaListScreen extends StatefulWidget {
  const MediaListScreen({
    super.key,
    required this.user,
    this.initialType,
    this.initialStatus,
  });

  final AppUser user;
  final MediaType? initialType;
  final EntryStatus? initialStatus;

  @override
  State<MediaListScreen> createState() => _MediaListScreenState();
}

class _MediaListScreenState extends State<MediaListScreen> {
  List<MediaEntry> _entries = [];
  bool _loading = true;
  MediaType? _type;
  EntryStatus? _status;
  SortOption _sort = SortOption.newest;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _type = widget.initialType;
    _status = widget.initialStatus;
    _load();
  }

  Future<void> _load() async {
    try {
      final entries = await DatabaseHelper.instance.getEntries(widget.user.id!);
      if (!mounted) return;
      setState(() {
        _entries = entries;
        _loading = false;
      });
    } catch (e) {
      // Storage error: keep the app running and tell the user.
      if (!mounted) return;
      setState(() => _loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not load your saved log. Pull down to retry.')),
      );
    }
  }

  /// Applies search, type filter, status filter, then sorting.
  List<MediaEntry> get _visible {
    final list = _entries.where((e) {
      if (_type != null && e.type != _type) return false;
      if (_status != null && e.status != _status) return false;
      if (_query.isNotEmpty &&
          !e.title.toLowerCase().contains(_query) &&
          !(e.notes ?? '').toLowerCase().contains(_query)) {
        return false;
      }
      return true;
    }).toList();

    switch (_sort) {
      case SortOption.newest:
        list.sort((a, b) => b.sortDate.compareTo(a.sortDate));
      case SortOption.oldest:
        list.sort((a, b) => a.sortDate.compareTo(b.sortDate));
      case SortOption.ratingHigh:
        list.sort((a, b) => (b.rating ?? -1).compareTo(a.rating ?? -1));
      case SortOption.ratingLow:
        list.sort((a, b) => (a.rating ?? 99).compareTo(b.rating ?? 99));
      case SortOption.titleAZ:
        list.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      case SortOption.updated:
        list.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    }
    return list;
  }

  Future<void> _openEntry(MediaEntry entry) async {
    await Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => EntryDetailScreen(user: widget.user, entry: entry),
    ));
    _load();
  }

  Future<void> _addEntry() async {
    final saved = await Navigator.of(context).push<bool>(MaterialPageRoute(
      builder: (_) => EntryFormScreen(user: widget.user),
    ));
    await _load();
    if (saved == true && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Entry added to your log')),
      );
    }
  }

  /// Swipe-to-delete with an Undo button (safer than instant, permanent delete).
  Future<void> _deleteWithUndo(MediaEntry entry) async {
    setState(() => _entries.removeWhere((e) => e.id == entry.id));
    try {
      await DatabaseHelper.instance.deleteEntry(entry.id!);
    } catch (e) {
      await _load();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not delete this entry. Try again.')),
      );
      return;
    }
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text('"${entry.title}" deleted'),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () async {
            await DatabaseHelper.instance.insertEntry(entry);
            _load();
          },
        ),
      ));
  }

  Widget _chip({
    required String label,
    IconData? icon,
    required bool selected,
    required VoidCallback onTap,
  }) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        avatar: icon == null ? null : Icon(icon, size: 18),
        showCheckmark: false,
        selected: selected,
        onSelected: (_) => onTap(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = _visible;
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Log'),
        actions: [
          PopupMenuButton<SortOption>(
            icon: const Icon(Icons.sort),
            tooltip: 'Sort',
            initialValue: _sort,
            onSelected: (s) => setState(() => _sort = s),
            itemBuilder: (context) => [
              for (final s in SortOption.values)
                PopupMenuItem(value: s, child: Text(s.label)),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addEntry,
        tooltip: 'Add entry',
        child: const Icon(Icons.add),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _query = v.trim().toLowerCase()),
              decoration: const InputDecoration(
                hintText: 'Search titles or notes',
                prefixIcon: Icon(Icons.search),
                isDense: true,
              ),
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _chip(
                  label: 'All types',
                  selected: _type == null,
                  onTap: () => setState(() => _type = null),
                ),
                for (final t in MediaType.values)
                  _chip(
                    label: t.label,
                    icon: t.icon,
                    selected: _type == t,
                    onTap: () => setState(() => _type = _type == t ? null : t),
                  ),
              ],
            ),
          ),
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              children: [
                _chip(
                  label: 'Any status',
                  selected: _status == null,
                  onTap: () => setState(() => _status = null),
                ),
                for (final s in EntryStatus.values)
                  _chip(
                    label: s.label,
                    icon: s.icon,
                    selected: _status == s,
                    onTap: () => setState(() => _status = _status == s ? null : s),
                  ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(
              children: [
                Text(
                  '${visible.length} ${visible.length == 1 ? 'entry' : 'entries'}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const Spacer(),
                Text(
                  '${_sort.label} · swipe left to delete',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ],
            ),
          ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : RefreshIndicator(
                    onRefresh: _load,
                    child: visible.isEmpty
                        ? ListView(
                            children: const [
                              EmptyState(
                                icon: Icons.search_off,
                                title: 'Nothing here',
                                message: 'Try another filter, or add a new entry.',
                              ),
                            ],
                          )
                        : ListView.builder(
                            padding: EdgeInsets.fromLTRB(
                                sidePadding(context), 4, sidePadding(context), 96),
                            itemCount: visible.length,
                            itemBuilder: (context, i) {
                              final entry = visible[i];
                              return FadeSlideIn(
                                index: i,
                                child: Dismissible(
                                  key: ValueKey('entry-${entry.id}'),
                                  direction: DismissDirection.endToStart,
                                  onDismissed: (_) => _deleteWithUndo(entry),
                                  background: Container(
                                    margin: const EdgeInsets.only(bottom: 10),
                                    padding: const EdgeInsets.symmetric(horizontal: 20),
                                    alignment: Alignment.centerRight,
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).colorScheme.error,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: Icon(Icons.delete_outline,
                                        color: Theme.of(context).colorScheme.onError),
                                  ),
                                  child: EntryTile(
                                    entry: entry,
                                    onTap: () => _openEntry(entry),
                                  ),
                                ),
                              );
                            },
                          ),
                  ),
          ),
        ],
      ),
    );
  }
}
