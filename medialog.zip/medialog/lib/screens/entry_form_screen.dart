import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../db/database_helper.dart';
import '../models/app_user.dart';
import '../models/media_entry.dart';
import '../models/media_types.dart';
import '../services/book_api_service.dart';
import '../utils/format.dart';
import '../widgets/common.dart';
import '../widgets/cover_image.dart';
import '../widgets/rating_stars.dart';
import 'book_search_screen.dart';

/// Used for both adding a new entry and editing an existing one.
/// Pops with `true` when something was saved.
class EntryFormScreen extends StatefulWidget {
  const EntryFormScreen({super.key, required this.user, this.entry});

  final AppUser user;
  final MediaEntry? entry; // null = add mode

  @override
  State<EntryFormScreen> createState() => _EntryFormScreenState();
}

class _EntryFormScreenState extends State<EntryFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _notes;
  late MediaType _type;
  late EntryStatus _status;
  late double _rating;
  DateTime? _date;
  String? _coverPath;
  bool _saving = false;
  bool _fetchingCover = false;

  bool get _isEdit => widget.entry != null;

  @override
  void initState() {
    super.initState();
    final e = widget.entry;
    _title = TextEditingController(text: e?.title ?? '');
    _notes = TextEditingController(text: e?.notes ?? '');
    _type = e?.type ?? MediaType.movie;
    _status = e?.status ?? EntryStatus.completed;
    _rating = e?.rating ?? 0;
    _date = e?.dateConsumed;
    _coverPath = e?.coverPath;
  }

  @override
  void dispose() {
    _title.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickCover() async {
    try {
      final picked = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 900,
        imageQuality: 80,
      );
      if (picked == null) return;
      // Copy into the app's own folder so the image survives cache clears.
      final dir = await getApplicationDocumentsDirectory();
      final name = 'cover_${DateTime.now().millisecondsSinceEpoch}${p.extension(picked.path)}';
      final saved = await File(picked.path).copy(p.join(dir.path, name));
      if (!mounted) return;
      setState(() => _coverPath = saved.path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not load that image.')),
      );
    }
  }

  /// Opens the Open Library search and fills the form with the chosen book.
  Future<void> _searchOnline() async {
    final book = await Navigator.of(context).push<BookResult>(MaterialPageRoute(
      builder: (_) => BookSearchScreen(initialQuery: _title.text.trim()),
    ));
    if (book == null || !mounted) return;
    setState(() {
      _title.text = book.title;
      _type = MediaType.book;
    });
    final url = book.coverUrl(size: 'L');
    if (url == null) return;
    setState(() => _fetchingCover = true);
    try {
      final bytes = await BookApiService.downloadCover(url);
      final dir = await getApplicationDocumentsDirectory();
      final file = File(p.join(dir.path, 'cover_${DateTime.now().millisecondsSinceEpoch}.jpg'));
      await file.writeAsBytes(bytes);
      if (!mounted) return;
      setState(() => _coverPath = file.path);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Book added, but the cover could not be downloaded.')),
      );
    } finally {
      if (mounted) setState(() => _fetchingCover = false);
    }
  }

  Future<void> _pickDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _date ?? now,
      firstDate: DateTime(1900),
      lastDate: DateTime(now.year + 1, 12, 31),
    );
    if (picked != null) setState(() => _date = picked);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    final now = DateTime.now();
    var date = _date;
    if (_status == EntryStatus.completed && date == null) date = now;
    final notes = _notes.text.trim();

    final entry = MediaEntry(
      id: widget.entry?.id,
      userId: widget.user.id!,
      title: _title.text.trim(),
      type: _type,
      status: _status,
      // Planned items have not been consumed yet, so they have no rating.
      rating: (_status == EntryStatus.planned || _rating == 0) ? null : _rating,
      notes: notes.isEmpty ? null : notes,
      dateConsumed: date,
      coverPath: _coverPath,
      createdAt: widget.entry?.createdAt ?? now,
      updatedAt: now,
    );

    try {
      if (_isEdit) {
        await DatabaseHelper.instance.updateEntry(entry);
      } else {
        await DatabaseHelper.instance.insertEntry(entry);
      }
      if (!mounted) return;
      Navigator.of(context).pop(true);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final text = Theme.of(context).textTheme;
    return Scaffold(
      appBar: AppBar(title: Text(_isEdit ? 'Edit entry' : 'New entry')),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: FilledButton.icon(
            onPressed: (_saving || _fetchingCover) ? null : _save,
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            icon: const Icon(Icons.check),
            label: Text(_isEdit ? 'Save changes' : 'Add to log'),
          ),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
          children: [
            // Cover
            Row(
              children: [
                _fetchingCover
                    ? const SizedBox(
                        width: 84,
                        height: 118,
                        child: Center(child: CircularProgressIndicator()),
                      )
                    : CoverImage(
                        path: _coverPath,
                        type: _type,
                        width: 84,
                        height: 118,
                      ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Cover (optional)', style: text.titleSmall),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(
                        onPressed: _pickCover,
                        icon: const Icon(Icons.add_photo_alternate_outlined),
                        label: Text(_coverPath == null ? 'Choose image' : 'Change image'),
                      ),
                      if (_coverPath != null)
                        TextButton(
                          onPressed: () => setState(() => _coverPath = null),
                          child: const Text('Remove'),
                        ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Title
            TextFormField(
              controller: _title,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                labelText: 'Title',
                prefixIcon: Icon(Icons.title),
              ),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Title is required' : null,
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: OutlinedButton.icon(
                onPressed: _fetchingCover ? null : _searchOnline,
                icon: const Icon(Icons.travel_explore),
                label: const Text('Search book online (Open Library)'),
              ),
            ),

            // Type
            const SectionTitle('Media type'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final t in MediaType.values)
                  ChoiceChip(
                    label: Text(t.label),
                    avatar: Icon(t.icon, size: 18),
                    showCheckmark: false,
                    selected: _type == t,
                    onSelected: (_) => setState(() => _type = t),
                  ),
              ],
            ),

            // Status
            const SectionTitle('Status'),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final s in EntryStatus.values)
                  ChoiceChip(
                    label: Text(s.label),
                    avatar: Icon(s.icon, size: 18),
                    showCheckmark: false,
                    selected: _status == s,
                    onSelected: (_) => setState(() => _status = s),
                  ),
              ],
            ),

            // Rating (hidden for planned items)
            if (_status != EntryStatus.planned) ...[
              const SectionTitle('Your rating'),
              Row(
                children: [
                  RatingStars(
                    rating: _rating,
                    size: 32,
                    onChanged: (r) => setState(() => _rating = r),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      ratingWords[_rating.round()],
                      style: text.bodyMedium?.copyWith(color: scheme.onSurfaceVariant),
                    ),
                  ),
                ],
              ),
            ],

            // Date
            const SectionTitle('Date consumed'),
            Material(
              color: scheme.surfaceContainerHighest,
              borderRadius: BorderRadius.circular(14),
              child: ListTile(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                leading: const Icon(Icons.calendar_today_outlined),
                title: Text(_date == null ? 'Not set' : formatDate(_date!)),
                subtitle: _status == EntryStatus.completed && _date == null
                    ? const Text("Today's date will be used")
                    : null,
                trailing: _date == null
                    ? null
                    : IconButton(
                        onPressed: () => setState(() => _date = null),
                        icon: const Icon(Icons.close),
                        tooltip: 'Clear date',
                      ),
                onTap: _pickDate,
              ),
            ),

            // Notes
            const SectionTitle('Review / notes'),
            TextFormField(
              controller: _notes,
              maxLines: 5,
              maxLength: 500,
              textCapitalization: TextCapitalization.sentences,
              decoration: const InputDecoration(
                hintText: 'What stuck with you?',
                alignLabelWithHint: true,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
